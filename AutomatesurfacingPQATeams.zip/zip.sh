#!/bin/bash
zip -r AutomatesurfacingPQATeams.zip .
